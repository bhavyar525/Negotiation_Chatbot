import logging
import google.generativeai as genai
from django.shortcuts import render
from django.conf import settings

logger = logging.getLogger(__name__)

genai.configure(api_key=settings.GEMINI_API_KEY)

def call_ai_model(prompt):
    model = genai.GenerativeModel("gemini-1.5-flash")
    
    try:
        response = model.generate_content(prompt)
        return response.text.strip()  # Adjust based on the actual response structure
    except Exception as e:
        logger.error(f"Error calling Gemini AI API: {e}")
        return "Error generating AI response. Please try again."

def NegotiationView(request):
    response = ""  # Initialize response variable
    product_name = ""  # Initialize product name variable
    price_range = None  # Initialize price_range variable to None

    if request.method == 'POST':
        product_name = request.POST.get('product_name')
        price_range = request.POST.get('price_range', 0)  # Default to 0 if not provided
        user_input = request.POST.get('offer')

        if product_name and user_input:
            try:
                user_price = int(user_input)
                price_range = int(price_range)

                # Basic response logic
                if user_price >= price_range:
                    response = f"Congratulations, you have accepted the offer for {product_name}!"
                elif user_price < price_range:
                    counteroffer = price_range - 10
                    response = f"I can offer you a discount of 10% on {product_name}. The new price is ${counteroffer}."
                else:
                    response = f"Sorry, your offer for {product_name} is too low. Please try again."
                
                # Call Gemini AI API
                prompt = f"User wants to buy {product_name} for ${user_price}. The product price range is ${price_range}. Respond with a negotiation message."
                ai_response = call_ai_model(prompt)  # Call the AI model
                
                if ai_response:
                    logger.info(f"User input: {user_input}, Price range: {price_range}, User price: {user_price}, AI response: {ai_response}")
                    response += f"<br>AI Response: {ai_response}"  # Append AI response to the output
                
                logger.info(f"Final response: {response}")

            except ValueError:
                response = "Please enter valid numeric values for price and offer."

    # Render the template with the current state
    return render(request, 'index.html', {'response': response, 'product_name': product_name, 'price_range': price_range})