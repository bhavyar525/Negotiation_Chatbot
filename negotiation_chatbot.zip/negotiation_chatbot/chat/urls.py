from django.urls import path
from .views import NegotiationView 

urlpatterns = [
    path('', NegotiationView, name='negotiation'), 
    path('negotiation/', NegotiationView, name='negotiation'),
]